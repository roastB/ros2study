import math
from geometry_msgs.msg import Twist

class Controller:
    def __init__(self, params):
        self.p = params

    def rotate(self, err_deg):
        t = Twist()
        if abs(err_deg) < self.p['angle_tolerance']:
            t.angular.z = 0.0
        else:
            t.angular.z = math.copysign(self.p['fixed_omega'], err_deg)
        return t

    def drive(self):
        t = Twist()
        t.linear.x = self.p['drive_speed']
        return t

from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='driver',
            executable='drive_node',
            name='drive_node',
            output='screen',
            parameters=[{
                'fixed_omega':        0.1,
                'turn_interval':      0.03,
                'pause_interval':     0.07,
                'drive_speed':        0.1,
                'angle_tolerance':    3.0,
                'mini_deg':           20.0,
                'mini_rad':           20.0 * 3.14159/180.0,
                'obs_detect_thresh':  0.15,
                'obs_clear_thresh':   0.25,
                'side_detect_thresh': 0.15,
                'drive_obs_time':     0.3,
                'surf_drive_time':    0.3,
                'too_close_thresh':   0.10,
                'arrival_radius':     0.05,
            }],
        ),
    ])

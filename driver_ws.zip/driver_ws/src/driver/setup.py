from setuptools import setup
import os

package_name = 'driver'

setup(
    name=package_name,
    version='0.0.1',
    packages=[package_name],
    data_files=[
        # ament resource 인덱스
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        # 런치 파일 설치 경로
        (os.path.join('share', package_name, 'launch'), ['launch/drive.launch.py']),
        # package.xml 자동 설치
        (os.path.join('share', package_name), ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='pinky',
    maintainer_email='iceative12@gmail.com',
    description='DriveNode 기반 주행 패키지',
    license='Apache-2.0',
    entry_points={
        'console_scripts': [
            # ros2 run driver drive_node 로 실행 가능
            'drive_node = driver.drive_node:main',
        ],
    },
)

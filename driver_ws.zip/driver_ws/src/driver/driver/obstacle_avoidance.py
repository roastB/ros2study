import numpy as np
import math

def compute_distances(ranges, angle_increment):
    N = len(ranges)
    mid = N // 2
    span = int(math.radians(5) / angle_increment)
    def md(idx):
        w = np.concatenate([ranges[idx-span:idx], ranges[idx:idx+span+1]])
        v = w[(w>0)&~np.isinf(w)]
        return float(v.min()) if v.size else float('nan')
    return md(mid), md((mid-N//4)%N), md((mid+N//4)%N)

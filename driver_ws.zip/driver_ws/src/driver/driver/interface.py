from geometry_msgs.msg import PointStamped, Twist
from std_msgs.msg import Int32, Empty
from sensor_msgs.msg import LaserScan

class Interface:
    def __init__(self, node, cbs):
        self.pose_sub    = node.create_subscription(PointStamped, '/robot_pose',    cbs['pose_cb'],        10)
        self.front_sub   = node.create_subscription(PointStamped, '/robot_front',   cbs['front_cb'],       10)
        self.wp6_sub     = node.create_subscription(PointStamped, '/waypoint_6',    cbs['wp6_cb'],         10)
        self.wp7_sub     = node.create_subscription(PointStamped, '/waypoint_7',    cbs['wp7_cb'],         10)
        self.target_sub  = node.create_subscription(Int32,        '/target_marker', cbs['target_cb'],      10)
        self.point_sub   = node.create_subscription(PointStamped, '/target_point',  cbs['target_point_cb'],10)
        self.scan_sub    = node.create_subscription(LaserScan,    '/scan',          cbs['scan_cb'],        10)
        self.arrived_sub = node.create_subscription(Empty,        '/arrived',       cbs['arrived_cb'],     10)
        self.cmd_pub     = node.create_publisher(Twist, '/cmd_vel', 10)
